//
//  ViewController.swift
//  UnicornCoffee
//
//  Created by robin on 2017-11-07.
//  Copyright © 2017 robin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    // outlets
    
    @IBOutlet weak var switchWhippedCream: UISwitch!
    
    @IBOutlet weak var lblTotal: UILabel!
    
    @IBOutlet weak var chok: UISwitch!
    
    
    @IBOutlet weak var num: UILabel!
    
    
    @IBOutlet weak var name: UITextField!
    
    // variables
    var x = 0
    
    
    // actions
    
    
    @IBAction func btnOrderClicked(_ sender: UIButton) {
        let n = name.text!
        if(switchWhippedCream.isOn == true && chok.isOn == true ){
            lblTotal.text = " \(n) Total Price : $ \(8*x)"
        }
        else if(switchWhippedCream.isOn == true)
        
        {
            lblTotal.text = "\(n) Total Price : $ \(6*x)"
        }
        else if(chok.isOn == true)
            
        {
           lblTotal.text = "\(n) Total Price : $ \(7*x)"
        }
            
            
            
        else
        {
          lblTotal.text = "\(n) Total Price : $ \(5*x)"
        }
      
    }
    
    @IBAction func btn1(_ sender: UIButton) {
        x=x+1
        num.text = "\(x)"
    }
    
    @IBAction func btn2(_ sender: UIButton) {
        x=x-1
        if (x<=0){
           x=0
            
        }
        num.text = "\(x)"
    }
    
    
    
    
}

